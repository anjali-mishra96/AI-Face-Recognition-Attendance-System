# Face-Recognition-based-Attendance-System-using-Opencv-Python
Face Recognition based Attendance System using Opencv Python and pillow
